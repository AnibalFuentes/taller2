package ejercicio_4;

import java.util.Scanner;

public class Ejercicio_4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        int[] nuevosaldo;
        int[] abo;
        int[] sal;
        int[] dedu;
        int[] lim;
        System.out.print("Cantidad de clientes al ingresar: ");
        n = sc.nextInt();
        lim = new int[n];
        sal = new int[n];
        nuevosaldo = new int[n];
        abo = new int[n];
        dedu = new int[n];

        for (int i = 1; i <= n; i++) {
            System.out.println("------------------------------------");
            System.out.println("* recopilacion de datos #" + i + " *");
            System.out.print("Salario inicial: ");
            sal[i - 1] = sc.nextInt();
            System.out.print("Abonos mensual: ");
            abo[i - 1] = sc.nextInt();
            System.out.print("Deduccion mensual: ");
            dedu[i - 1] = sc.nextInt();
            System.out.print("Limite de credito: ");
            lim[i - 1] = sc.nextInt();
            System.out.println("------------------------------------");
        }

        for (int x = 1; x <= n; x++) {
            nuevosaldo[x - 1] = (sal[x - 1] + abo[x - 1]) - dedu[x - 1];
            System.out.println("cliente #" + x + " su balance es: " + nuevosaldo[x - 1]);
            if (nuevosaldo[x - 1] > lim[x - 1]) {
                System.out.println("El cliente #" + x + ", sobrepasó el limite de su credito.");
            }
        }
    }
}
