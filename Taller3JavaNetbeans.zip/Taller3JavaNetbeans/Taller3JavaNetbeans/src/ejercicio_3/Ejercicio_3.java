package ejercicio_3;

import java.util.Scanner;

public class Ejercicio_3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int comision = 200;
        int[] semana;
        int sumasemana = 0;
        float total;
        int subto = 0;
        int n;
        semana = new int[8];
        System.out.println("PAGO POR COMISION");
        System.out.print("Cantidad de vendedores: ");
        n = sc.nextInt();

        for (int i = 1; i <= n; i++) {
            System.out.println("");
            System.out.println(i + ". Ganancia semanal del [Vendedor #" + i + "]: ");
            semana[i] = sc.nextInt();
        }
        for (int i = 1; i <= n; i++) {
            System.out.println("Incremento en categoria A del vendedor #" + i + ": ");
            if (sumasemana <= 3000) {
                subto = (sumasemana * 14) / 100;
                total = sumasemana + subto + comision;
                System.out.println("Su pago de esta semana es: " + total);
            } else {
                if (sumasemana <= 4000) {
                    subto = ((sumasemana * 9) / 100);
                    total = sumasemana + subto + comision;
                    System.out.println("Su pago de esta semana es: " + total);
                }
            }
            if (sumasemana >= 5000) {
                if (sumasemana <= 7000) {
                    subto = (sumasemana * 16) / 100;
                    total = sumasemana + subto + comision;
                    System.out.println("Su pago de esta semana es: " + total);
                }
            }

            if (sumasemana > 7000) {
                subto = ((sumasemana * 19) / 100);
                total = sumasemana + subto + comision;
                System.out.println("Su pago de esta semana es: " + total);
            }

            System.out.println("incremento en categoria B del vendedor #" + i + ":");
            if (sumasemana <= 5000) {
                subto = (sumasemana * 16) / 100;
                total = sumasemana + subto + comision;
                System.out.println("Su pago de esta semana es: " + total);
            } else {
                subto = ((sumasemana * 9) / 100);
                total = sumasemana + subto + comision;
                System.out.println("Su pago de esta semana es: " + total);
            }

            if (sumasemana >= 10000) {
                if (sumasemana <= 15000) {
                    subto = ((sumasemana * 19) / 100);
                    total = sumasemana + subto + comision;
                    System.out.println("Su pago de esta semana es: " + total);
                }
            }
            if (sumasemana >= 15000) {
                subto = ((sumasemana * 22) / 100);
                total = sumasemana + subto + comision;
                System.out.println("Su pago de esta semana es: " + total);
            }
            sumasemana = 0;
            System.out.print("");
        }

    }
}
