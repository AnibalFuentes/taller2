package ejercicio_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio_2 {

    public static void main(String[] args) throws IOException {
        BufferedReader bufEntrada = new BufferedReader(new InputStreamReader(System.in));
        int a[];
        int b[];
        int c[];
        double cred;
        double d[];
        double data = 0;
        double datb = 0;
        double datc = 0;
        int i;
        int j;
        int n;
        double total;
        int x;
        n = 0;
        System.out.print("Cantidad de trabajadores: ");
        n = Integer.parseInt(bufEntrada.readLine());
        a = new int[n];
        b = new int[n];
        c = new int[n];
        d = new double[n];
        System.out.println("-----------------------------");
        System.out.println("Salarios mensuales iniciales:");
        for (i = 1; i <= n; i++) {
            a[i - 1] = (int) (Math.random() * 1000);
            System.out.println("[Trabajador " + i + "]:          $" + a[i - 1]);
        }
        System.out.println("-----------------------------");
        System.out.println("Abonos mensuales: ");
        for (i = 1; i <= n; i++) {
            b[i - 1] = (int) (Math.random() * 10);
            System.out.println("[Trabajador " + i + "]:          $" + b[i - 1]);
        }
        System.out.println("-----------------------------");
        System.out.println("Deducciones mensuales:");
        for (i = 1; i <= n; i++) {
            c[i - 1] = (int) (Math.random() * 30);;
            System.out.println("[Trabajador " + i + "]:         -$" + c[i - 1]);
        }
        System.out.println("-----------------------------");
        System.out.println("");
        System.out.println("-------------- Nuevos saldos:");
        for (j = 1; j <= n; j++) {
            data = data + a[j - 1];
            datb = datb + b[j - 1];
            datc = datc + c[j - 1];
            total = data + datb - datc;
            d[j - 1] = total;
            System.out.println("[Trabajador " + j + "]:       [$" + total + "]");
        }
        System.out.println("-----------------------------");
        cred = 1000;
        System.out.println("*** CREDITO MINIMO: $" + cred + " ***");
        for (x = 1; x <= n; x++) {
            if (d[x - 1] < cred) {
                System.out.println("[Trabajador " + x + "] Exedió el limite del credito.");
            }
        }
    }
}
