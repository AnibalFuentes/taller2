
package ejercicio_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Ejercicio_1 {
    public static void main(String[] args) throws IOException {
        BufferedReader bufEntrada = new BufferedReader(new InputStreamReader(System.in));
        //Declaramos las variables correspondientes
        int A[], B[], C[];
        int i, x, z, n;
        int may;
        int maycos;
        int pos = 0;
        int poscos = 0;
        int cantprod = 0;
        double totalinq = 0;

        // Ingresamos la cantidad de productos vendidos en el día
        System.out.print("Cantidad de productos vendidos: ");
        n = Integer.parseInt(bufEntrada.readLine());
        A = new int[n];
        B = new int[n];
        C = new int[n];
        // Imprimimos los códigos de cada producto respectivamentre
        System.out.println("-------------------------------------");
        System.out.println("Codigos de los productos:  (Vector A)");
        for (i = 1; i <= n; i++) {
            A[i - 1] = (int) (Math.random() * 50);
            System.out.println("[PROD " + i + "]: COD" + A[i - 1]);
        }
        // Imprimimos los valores  de cada producto respectivamente
        System.out.println("-------------------------------------");
        System.out.println("Precio de los productos:   (Vector B)");
        for (i = 1; i <= n; i++) {
            B[i - 1] = (int) (Math.random() * 5000);
            System.out.println("[PROD " + i + "]: $" + B[i - 1]);
        }
        // Imprimimos la cantidad de productos vendidos respectivamentre 
        System.out.println("-------------------------------------");
        System.out.println("Cantidad de ventas * prod: (Vector C)");
        for (i = 1; i <= n; i++) {
            C[i - 1] = (int) (Math.random() * 100);
            System.out.println("[PROD " + i + "]: " + C[i - 1] + " VENDIDOS");
        }

        for (x = 1; x <= n; x++) {
            cantprod = cantprod + C[x - 1];
            totalinq = totalinq + B[x - 1];
        }
        // Producto más vendido
        may = C[0];
        for (z = 1; z <= n; z++) {
            if (C[z - 1] > may) {
                may = C[z - 1];
            }
        }
        for (z = 1; z <= n; z++) {
            if (may == C[z - 1]) {
                pos = z;
            }
        }
        // Producto costoso más vendido
        maycos = B[0];
        for (z = 1; z <= n; z++) {
            if (B[z - 1] > maycos) {
                maycos = B[z - 1];
            }
        }
        for (z = 1; z <= n; z++) {
            if (maycos == B[z - 1]) {
                poscos = z;
            }
        }
        // Imprimimos los resultados de las operaciones en pantalla
        System.out.println("------------------------- Resultados:");
        System.out.println("| Cant. productos vendidos:  [" + cantprod + "]");
        System.out.println("| Total ingresos:            [$" + totalinq + "]");
        System.out.println("| Prod. más vendido:         [PROD." + pos + "]");
        System.out.println("| Prod. costoso más vendido: [PROD." + poscos + "]");
        System.out.println("------------------------- Finalizado.");
    }
}
