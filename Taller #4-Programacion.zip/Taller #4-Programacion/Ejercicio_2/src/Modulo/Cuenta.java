package Modulo;

import java.util.Scanner;

public class Cuenta {

    //Atributos de la clase
    int noCuenta;
    String nombreCliente;
    double saldo;

    //Constructor
    public Cuenta() {
    }

    public int getNoCuenta() {
        return noCuenta;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public double GetSaldo() {
        return saldo;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public void setNoCuenta(int n) {
        this.noCuenta = n;
    }

    public void setSaldo(double v) {
        this.saldo = v;
    }

    public double consignar() {
        Scanner sc = new Scanner(System.in);
        System.out.println("N° de cuenta: " + noCuenta);
        System.out.println("Nom. cliente: " + nombreCliente);
        System.out.println("Saldo actual: $" + saldo);
        System.out.println("/-------------------------------/");
        System.out.print("Valor de la consignación: ");
        double consg = sc.nextDouble();
        double total = saldo + consg;
        return total;
    }

    public double retirar() {
        Scanner sc = new Scanner(System.in);
        System.out.println("N° de cuenta: " + noCuenta);
        System.out.println("Nom. cliente: " + nombreCliente);
        System.out.println("Saldo actual: $" + saldo);
        System.out.println("/-------------------------------/");
        System.out.print("Valor del retiro: ");
        double reti = sc.nextDouble();
        double total = saldo - reti;
        return total;
    }

}
