package Modulo;

public class PruebaCuenta {

    public static void main(String[] args) {
        Cuenta cuenta1 = new Cuenta();
        Cuenta cuenta2 = new Cuenta();
        Cuenta cuenta3 = new Cuenta();
        //cliente 1
        cuenta1.noCuenta = 1;
        cuenta1.nombreCliente = "Anibal";
        cuenta1.saldo = 1000000;
        //cliente 2
        cuenta2.noCuenta = 2;
        cuenta2.nombreCliente = "Juan";
        cuenta2.saldo = 300000;
        //Metodo consignar
        double c1 = cuenta1.consignar();
        System.out.println("Nuevo saldo: " + c1 + "\n");
        //Metodo retirar
        double r1 = cuenta2.retirar();
        System.out.println("Nuevo saldo: " + r1 + "\n");
    }
}
