package Modelo;

public class Editorial {

    public Editorial() {

    }

    String editorial = "Prentice-Hall";

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }
}
