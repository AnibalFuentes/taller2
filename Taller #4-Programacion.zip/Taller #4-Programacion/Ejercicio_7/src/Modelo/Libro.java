package Modelo;

import java.util.Scanner;

public class Libro {

    String titulo;
    String priNom;
    String segNom;
    String priApe;
    String isbn;
    String paginas;
    String edicion;
    String ciudad;
    String pais;
    String fecEdicion;
    String editorial;

    public Libro() {
    }

    //Setters
    public String getTitulo() {
        return titulo;
    }

    public String getPriNom() {
        return priNom;
    }

    public String getSegNom() {
        return segNom;
    }

    public String getPriApe() {
        return priApe;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getPaginas() {
        return paginas;
    }

    public String getEdicion() {
        return edicion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public String getPais() {
        return pais;
    }

    public String getFecEdicion() {
        return fecEdicion;
    }

    //Getters
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setPriNom(String priNom) {
        this.priNom = priNom;
    }

    public void setSegNom(String segNom) {
        this.priNom = segNom;
    }

    public void setPriApe(String priApe) {
        this.priApe = priApe;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setPaginas(String paginas) {
        this.paginas = paginas;
    }

    public void setEdicion(String edicion) {
        this.edicion = edicion;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public void setFecEdicion(String fecEdicion) {
        this.fecEdicion = fecEdicion;
    }

    public String ingresarLibro() {
        Scanner sc = new Scanner(System.in);
        int n = 5;
        for (int i = 0; i < n; i++) {
            System.out.println("*** DATOS DEL LIBRO #" + (i + 1) + " ***");
            System.out.println("-----------------------");
            System.out.print("Título: ");
            String _titulo = sc.nextLine();
            System.out.print("Primer nombre (autor): ");
            String _priNom = sc.nextLine();
            System.out.print("Segundo nombre (autor): ");
            String _segNom = sc.nextLine();
            System.out.print("Primer apellido (autor): ");
            String _priApe = sc.nextLine();
            System.out.print("ISBN: ");
            String _isbn = sc.nextLine();
            System.out.print("Cant. páginas: ");
            String _paginas = sc.nextLine();
            System.out.print("Edición: ");
            String _edicion = sc.nextLine();
            System.out.print("Ciudad: ");
            String _ciudad = sc.nextLine();
            System.out.print("País: ");
            String _pais = sc.nextLine();
            System.out.print("Fecha de edición: ");
            String _fecEdicion = sc.nextLine();
            Editorial edit = new Editorial();
            System.out.print("Editorial: " + edit.getEditorial());
            System.out.println("");
            System.out.println("-----------------------");
        }
        return null;
    }

}
