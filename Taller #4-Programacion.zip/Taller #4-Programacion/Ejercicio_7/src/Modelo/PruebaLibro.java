package Modelo;

public class PruebaLibro {

    public static void main(String[] args) {

        //Objetos tipo libro
        Libro libro1 = new Libro();
        Libro libro2 = new Libro();
        Libro libro3 = new Libro();

        libro1.ingresarLibro();

    }

}
