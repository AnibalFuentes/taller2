package Modelo;

public class PruebaTriangulo {

    public static void main(String[] args) {
        Triangulo tr1 = new Triangulo();
        tr1.base = 6;
        tr1.altura = 8;
        tr1.ladoA = 12;
        tr1.ladoB = 12;
        tr1.ladoC = 12;

        tr1.area();
        tr1.longitud();
        tr1.perimetro();
        tr1.vertice();
    }
}
