package Modelo;

import static java.lang.Math.sqrt;
import java.util.Scanner;

public class Triangulo {

    double base;
    double altura;
    double ladoA;
    double ladoB;
    double ladoC;

    public Triangulo() {

    }

    public double area() {
        Scanner sc = new Scanner(System.in);
        System.out.println("AREA:");
        System.out.println("--------------------");
        System.out.println("Base: " + base);
        System.out.println("Altura: " + altura);
        System.out.println("--------------------");
        double area = (base * altura) / 2;
        System.out.println("Area total: " + area);
        System.out.println(" ");
        return area;
    }

    public double longitud() {
        Scanner sc = new Scanner(System.in);
        System.out.println("LONGITUD DE LOS LADOS:");
        System.out.println("--------------------");
        System.out.println("Base: " + base);
        System.out.println("Altura: " + altura);
        System.out.println("--------------------");
        double longitud = ((base * 2) + (altura * 2));
        System.out.println("Area total: " + longitud);
        System.out.println(" ");
        return longitud;
    }

    public double perimetro() {
        Scanner sc = new Scanner(System.in);
        System.out.println("PERIMETRO:");
        System.out.println("--------------------");
        System.out.println("Lado A: " + ladoA);
        System.out.println("Lado B: " + ladoB);
        System.out.println("Lado C: " + ladoC);
        System.out.println("--------------------");
        double perimetro = (ladoA + ladoB + ladoC);
        System.out.println("Perimetro: " + perimetro);
        System.out.println(" ");
        return perimetro;
    }

    public double vertice() {
        Scanner sc = new Scanner(System.in);
        System.out.println("ANGULO VERTICE:");
        System.out.println("--------------------");
        System.out.println("Lado A: " + ladoA);
        System.out.println("Lado B: " + ladoB);
        System.out.println("Lado C: " + ladoC);
        System.out.println("--------------------");
        double p = (ladoA + ladoB + ladoC);
        double vertice = sqrt(p * ((p - ladoA) * (p - ladoA) * (p - ladoA)));
        System.out.println("Vertice: " + vertice);
        System.out.println(" ");
        return vertice;
    }
}
