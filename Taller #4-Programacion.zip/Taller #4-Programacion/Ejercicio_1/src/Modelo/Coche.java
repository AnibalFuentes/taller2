package Modelo;

public class Coche {

    //Atributos de la clase
    String color;
    String marca;
    String modelo;
    String matricula;
    int numeroCaballo;
    int numeroPuerta;
    
    //Metodos de la clase
    public void desplegarDatos() {
        System.out.println("/-------------------/");
        System.out.println("color = " + color);
        System.out.println("marca = " + marca);
        System.out.println("modelo = " + modelo);
        System.out.println("numeroCaballo = " + numeroCaballo);
        System.out.println("numeroPuerta = " + numeroPuerta);
        System.out.println("matricula = " + matricula);
        System.out.println("/-------------------/");
    }

}
