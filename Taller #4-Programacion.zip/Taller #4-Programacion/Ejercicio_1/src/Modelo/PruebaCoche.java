package Modelo;

public class PruebaCoche {

    public static void main(String[] args) {
        //----------------------------------//
        //Objetos tipo Coche
        Coche coche1 = new Coche();
        Coche coche2 = new Coche();
        Coche coche3 = new Coche();
        Coche coche4 = new Coche();
        //Colores
        coche1.color = "Yellow";
        coche2.color = "Black";
        coche3.color = "White";
        //Marcas
        coche1.marca = "Toyota";
        coche2.marca = "Chevrolet";
        coche3.marca = "Mazda";
        //Modelos
        coche1.modelo = "Todoterreno";
        coche2.modelo = "grand touring";
        coche3.modelo = "deportivo";
        //Matriculas
        coche1.matricula = "CDQ 44E";
        coche2.matricula = "TVX 65H";
        coche3.matricula = "VFG ";
        //Numero de caballos
        coche1.numeroCaballo = 200;
        coche2.numeroCaballo = 300;
        coche3.numeroCaballo = 500;
        //Numero de puertas
        coche1.numeroPuerta = 4;
        coche2.numeroPuerta = 2;
        coche3.numeroPuerta = 2;
        //Mostrar objetos (3 coches)
        coche1.desplegarDatos();
        System.out.println("");
        coche2.desplegarDatos();
        System.out.println("");
        coche3.desplegarDatos();
        //----------------------------------//
    }
}
