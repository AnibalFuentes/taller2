package Punto2;

public class Punto2 {

    public static void main(String[] args) {
        float num1 = 12560;
        float num2 = 88553;
        float num3 = 40000;
        //Operaciones
        float suma = (num1 + num2 + num3);
        float promedio = ((num1 + num2 + num3) / 3);
        float producto = (num1 * num2 * num3);
        //Números en consola
        System.out.println("*** Punto 1 ***");
        System.out.println("Números ingresados: (" + num1 + ") (" + num2 + ") (" + num3
                + "\n--------------------------------------");
        //Resultados en consola
        System.out.println("Suma: " + suma);
        System.out.println("Promedio: " + String.format("%.1f", promedio));
        System.out.println("Producto: " + producto);
        System.out.println("--------------------------------------");

    }
}
