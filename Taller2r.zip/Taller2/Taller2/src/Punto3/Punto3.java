package Punto3;

import javax.swing.JOptionPane;

public class Punto3 {

    public static void main(String[] args) {
        int costoFijo = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el costo fijo del producto: "));
        float margenUtilidad = (float) 0.20;
        float precioVenta = costoFijo / (1 - margenUtilidad);
        float utilidad = precioVenta - costoFijo;

        JOptionPane.showMessageDialog(null, "(Margen de utilidad: 20%)\nPrecio de venta: %" + precioVenta + "\n" + "Utilidad: +%" + utilidad);

    }
}
