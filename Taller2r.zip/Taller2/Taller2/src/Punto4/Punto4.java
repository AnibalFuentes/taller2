package Punto4;

import javax.swing.JOptionPane;

public class Punto4 {

    public static void main(String[] args) {
        int diasViaje = Integer.parseInt(JOptionPane.showInputDialog(null, "Cantidad de días de viaje:"));
        int KmDia = Integer.parseInt(JOptionPane.showInputDialog(null, "cantidad de KM recorridos por día:"));
        int litroGasolina = Integer.parseInt(JOptionPane.showInputDialog(null, "Cantidad de litros de gasolina gastados por día:"));
        int valorGasolina = Integer.parseInt(JOptionPane.showInputDialog(null, "Valor del litro de gasolina:"));
        int pagoEstacionamiento = Integer.parseInt(JOptionPane.showInputDialog(null, "Cantidad de dinero gastado en estacionamiento por día:"));
        int pagoPeajeDia = Integer.parseInt(JOptionPane.showInputDialog(null, "Cantidad de dinero gastado en peaje por día:"));

        int totalKmDia = (int) (diasViaje * KmDia);
        int totalGasolina = (int) (diasViaje * litroGasolina);
        int totalLitroGasolina = (int) (valorGasolina * litroGasolina);
        int totalEstaccion = (int) (diasViaje * pagoEstacionamiento);
        int totalPeaje = (int) (diasViaje * pagoPeajeDia);
        int total = totalEstaccion + totalPeaje + totalLitroGasolina;

        JOptionPane.showMessageDialog(null, "Total de días de viaje: " + diasViaje + "\n"
                + "-----------------------------------------------------\n"
                + "Km gastados en el viaje: " + totalKmDia + "\n"
                + "Litros de gasolina gastados en el viaje: " + totalGasolina + "\n"
                + "Gastos en litros de gasolina: $" + totalLitroGasolina + "\n"
                + "Gastos en estacionamiento: $" + totalEstaccion + "\n"
                + "Gastos en peaje: $" + totalPeaje + "\n"
                + "-----------------------------------------------------"
                + "\nGasto totales del viaje: [$" + total + "]");

    }
}
