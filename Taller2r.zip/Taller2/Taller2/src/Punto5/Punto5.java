package Punto5;

public class Punto5 {

    public static void main(String[] args) {

    }
}
